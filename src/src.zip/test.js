
export let test = () => console.log("test import");